from __future__ import annotations
import os, hashlib, threading, subprocess, shutil, platform, time
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)
lock = threading.Lock()
STATE = {"running": False, "progress": 0, "total": 0, "folder": "",
         "results": [], "logs": [], "started": None, "finished": None}

VT_KEY = os.getenv("VT_API_KEY", "").strip()
KASPERSKY_KEY = os.getenv("OPENTIP_API_KEY", "").strip()
MAX_FILES = int(os.getenv("NEXUS_MAX_FILES", "3000"))
MAX_FILE_MB = int(os.getenv("NEXUS_MAX_FILE_MB", "100"))

def log(message):
    with lock:
        STATE["logs"].append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
        STATE["logs"] = STATE["logs"][-250:]

def sha256_file(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def find_defender():
    if platform.system() != "Windows":
        return None
    candidates = []
    program_data = os.getenv("ProgramData", r"C:\ProgramData")
    platform_dir = Path(program_data) / "Microsoft/Windows Defender/Platform"
    if platform_dir.exists():
        candidates.extend(sorted(platform_dir.glob("*/MpCmdRun.exe"), reverse=True))
    program_files = os.getenv("ProgramFiles", r"C:\Program Files")
    candidates.append(Path(program_files) / "Windows Defender/MpCmdRun.exe")
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return shutil.which("MpCmdRun.exe")

def scan_with_defender(folder):
    exe = find_defender()
    if not exe:
        return {"status": "indisponível", "detail": "MpCmdRun.exe não encontrado (ou sistema não Windows)."}
    try:
        proc = subprocess.run(
            [exe, "-Scan", "-ScanType", "3", "-File", str(folder)],
            capture_output=True, text=True, timeout=60 * 60 * 24
        )
        output = (proc.stdout or "") + "\n" + (proc.stderr or "")
        # Exit code 0 can mean clean OR detected and remediated; 2 means detection not remediated or error.
        if proc.returncode == 0:
            status = "concluído"
        elif proc.returncode == 2:
            status = "alerta_ou_erro"
        else:
            status = "erro"
        return {"status": status, "returncode": proc.returncode, "detail": output[-6000:]}
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "detail": "A verificação do Defender excedeu o tempo limite."}
    except Exception as exc:
        return {"status": "erro", "detail": str(exc)}

def scan_with_virustotal(file_hash):
    if not VT_KEY:
        return {"status": "sem_chave", "detections": None, "total": None, "label": "API não configurada"}
    try:
        r = requests.get(
            f"https://www.virustotal.com/api/v3/files/{file_hash}",
            headers={"x-apikey": VT_KEY}, timeout=20
        )
        if r.status_code == 404:
            return {"status": "desconhecido", "detections": None, "total": None, "label": "Hash não encontrado"}
        r.raise_for_status()
        stats = r.json().get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        malicious = int(stats.get("malicious", 0))
        suspicious = int(stats.get("suspicious", 0))
        total = sum(int(v or 0) for v in stats.values())
        return {"status": "consultado", "detections": malicious + suspicious,
                "malicious": malicious, "suspicious": suspicious, "total": total,
                "label": f"{malicious + suspicious}/{total}"}
    except requests.HTTPError as exc:
        return {"status": "erro", "detections": None, "total": None, "label": f"HTTP {exc.response.status_code}"}
    except Exception as exc:
        return {"status": "erro", "detections": None, "total": None, "label": str(exc)[:100]}

def scan_with_kaspersky(file_hash):
    if not KASPERSKY_KEY:
        return {"status": "sem_chave", "zone": None, "label": "API não configurada"}
    try:
        r = requests.get(
            "https://opentip.kaspersky.com/api/v1/search/hash",
            params={"request": file_hash},
            headers={"x-api-key": KASPERSKY_KEY}, timeout=20
        )
        if r.status_code == 404:
            return {"status": "desconhecido", "zone": None, "label": "Hash não encontrado"}
        r.raise_for_status()
        data = r.json()
        zone = str(data.get("Zone", "Grey"))
        label = {"Red": "Malicioso", "Orange": "Não confiável", "Yellow": "Adware / suspeito",
                 "Green": "Sem ameaças conhecidas", "Grey": "Sem dados suficientes"}.get(zone, zone)
        return {"status": "consultado", "zone": zone, "label": label}
    except requests.HTTPError as exc:
        return {"status": "erro", "zone": None, "label": f"HTTP {exc.response.status_code}"}
    except Exception as exc:
        return {"status": "erro", "zone": None, "label": str(exc)[:100]}

def calculate_risk_score(defender, vt, kaspersky):
    score = 0
    # Only positive, explicit detections add points. Unknown/unavailable is not clean.
    if defender.get("status") == "alerta_ou_erro":
        score += 50
    if vt.get("status") == "consultado":
        if vt.get("malicious", 0) > 0: score += 30
        elif vt.get("suspicious", 0) > 0: score += 15
    if kaspersky.get("zone") == "Red": score += 20
    elif kaspersky.get("zone") == "Orange": score += 12
    elif kaspersky.get("zone") == "Yellow": score += 8
    return min(score, 100)

def risk_label(score):
    if score >= 60: return "grave"
    if score >= 25: return "medio"
    return "suave"

def run_scan(folder, include_cloud):
    try:
        base = Path(folder).expanduser().resolve()
        if not base.exists() or not base.is_dir():
            raise ValueError("A pasta selecionada não existe ou não é uma pasta.")
        paths = []
        for p in base.rglob("*"):
            try:
                if p.is_file() and not p.is_symlink() and p.stat().st_size <= MAX_FILE_MB * 1024 * 1024:
                    paths.append(p)
                    if len(paths) >= MAX_FILES: break
            except (OSError, PermissionError):
                continue
        with lock:
            STATE["total"] = len(paths)
            STATE["progress"] = 0
            STATE["results"] = []
        log(f"{len(paths)} arquivo(s) elegível(is) encontrado(s). Limite: {MAX_FILES} arquivos; {MAX_FILE_MB} MB por arquivo.")
        defender = scan_with_defender(base)
        log(f"Windows Defender: {defender.get('status')}")
        for index, path in enumerate(paths, 1):
            try:
                digest = sha256_file(path)
                vt = scan_with_virustotal(digest) if include_cloud else {"status":"ignorado","label":"Ignorado"}
                kas = scan_with_kaspersky(digest) if include_cloud else {"status":"ignorado","label":"Ignorado"}
                # Defender varre a pasta inteira; seu resultado não identifica o arquivo específico.
                # Não atribuímos pontos do Defender a cada item para evitar falsos vínculos.
                score = calculate_risk_score({"status": "indisponivel"}, vt, kas)
                # Folder-level Defender output is shown separately; it is not attributed to every file.
                item = {
                    "name": path.name, "path": str(path), "size": path.stat().st_size,
                    "sha256": digest, "defender": defender["status"],
                    "vt": vt, "kaspersky": kas, "score": score, "risk": risk_label(score),
                    "classification": "alerta" if score >= 25 else "verificado"
                }
                with lock:
                    STATE["results"].append(item)
                    STATE["progress"] = index
                if index % 10 == 0 or index == len(paths):
                    log(f"Analisados {index}/{len(paths)} arquivos.")
            except Exception as exc:
                log(f"Falha ao analisar {path.name}: {exc}")
                with lock: STATE["progress"] = index
        log("Varredura finalizada.")
    except Exception as exc:
        log(f"Erro na varredura: {exc}")
    finally:
        with lock:
            STATE["running"] = False
            STATE["finished"] = datetime.now().isoformat(timespec="seconds")

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/state")
def api_state():
    with lock:
        return jsonify(STATE)

@app.post("/api/scan")
def start_scan():
    payload = request.get_json(force=True)
    folder = (payload.get("folder") or "").strip()
    include_cloud = bool(payload.get("cloud", True))
    if not folder:
        return jsonify({"error": "Selecione uma pasta."}), 400
    with lock:
        if STATE["running"]:
            return jsonify({"error": "Já existe uma varredura em andamento."}), 409
        STATE.update({"running": True, "progress": 0, "total": 0, "folder": folder,
                      "results": [], "logs": [], "started": datetime.now().isoformat(timespec="seconds"),
                      "finished": None})
    threading.Thread(target=run_scan, args=(folder, include_cloud), daemon=True).start()
    return jsonify({"ok": True})

@app.get("/api/config")
def config():
    return jsonify({"virus_total": bool(VT_KEY), "kaspersky": bool(KASPERSKY_KEY),
                    "defender_supported": platform.system() == "Windows",
                    "max_files": MAX_FILES, "max_file_mb": MAX_FILE_MB})

if __name__ == "__main__":
    print("NEXUS SCAN disponível em http://127.0.0.1:5050")
    app.run(host="127.0.0.1", port=5050, debug=False, threaded=True)

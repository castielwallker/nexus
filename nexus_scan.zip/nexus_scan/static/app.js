const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let allResults=[], currentFilter='all', currentClass='all';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function icons(){if(window.lucide)lucide.createIcons()}
function showView(name){$$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));$$('.nav[data-view]').forEach(n=>n.classList.toggle('active',n.dataset.view===name));$('#pageTitle').textContent=({dashboard:'Dashboard',verified:'Verificados',results:'Resultado',detected:'Detectados',settings:'Configurações'})[name]||name;$('#sidebar').classList.remove('mobile-open');}
$$('.nav[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$$('[data-view-link]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.viewLink)));
$$('.nav-parent>.nav').forEach(b=>b.addEventListener('click',()=>{b.parentElement.classList.toggle('open');showView(b.dataset.view)}));
$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{currentFilter=b.dataset.filter;$$('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));renderTables()}));
$$('[data-class]').forEach(b=>b.addEventListener('click',()=>{currentClass=b.dataset.class;$$('[data-class]').forEach(x=>x.classList.toggle('active',x===b));renderTables()}));
$('#collapse').addEventListener('click',()=>document.body.classList.toggle('collapsed'));
$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('mobile-open'));
$('#themeToggle').addEventListener('click',()=>{let dark=document.documentElement.dataset.theme!=='dark';document.documentElement.dataset.theme=dark?'dark':'light';$('#themeToggle').innerHTML=`<i data-lucide="${dark?'sun':'moon'}"></i>`;icons();});
function fileName(r){return `<span class="file-cell"><i data-lucide="file"></i>${esc(r.name)}</span>`}
function risk(r){return `<span class="risk ${esc(r.risk)}">${r.risk==='grave'?'Risco grave':r.risk==='medio'?'Risco médio':'Risco suave'}</span>`}
function row(r,full=false){return `<tr><td>${fileName(r)}</td>${full?`<td title="${esc(r.sha256)}">${esc(r.sha256.slice(0,14))}…</td><td>${esc(r.defender)}</td>`:''}<td>${esc(r.vt?.label||'—')}</td><td>${esc(r.kaspersky?.label||'—')}</td>${full?'':'<td>'}${risk(r)}${full?`</td><td>${r.score}/100</td>`:''}</tr>`}
function renderTables(){
  const recent=allResults.slice(-6).reverse();
  $('#recentRows').innerHTML=recent.length?recent.map(r=>row(r)).join(''):'<tr><td colspan="4" class="empty">Nenhum arquivo analisado ainda.</td></tr>';
  $('#verifiedRows').innerHTML=allResults.filter(r=>r.score<25).map(r=>row(r,true)).join('')||'<tr><td colspan="6" class="empty">Nenhum arquivo nesta categoria.</td></tr>';
  $('#resultRows').innerHTML=allResults.filter(r=>currentFilter==='all'||r.risk===currentFilter).map(r=>row(r,true)).join('')||'<tr><td colspan="6" class="empty">Nenhum resultado para este filtro.</td></tr>';
  let detected=allResults.filter(r=>r.score>=25);
  if(currentClass==='falso')detected=[];
  else if(currentClass==='alerta')detected=detected;
  $('#detectedRows').innerHTML=detected.map(r=>`<tr><td>${fileName(r)}</td><td>${esc(r.vt?.label||'—')}</td><td>${esc(r.kaspersky?.label||'—')}</td><td>${risk(r)}</td><td><button class="text-btn" title="Classificação manual indisponível nesta versão">Revisar</button></td></tr>`).join('')||'<tr><td colspan="5" class="empty">Nenhum alerta nesta categoria.</td></tr>';
  $('#totalFiles').textContent=allResults.length;
  $('#cleanFiles').textContent=allResults.filter(r=>r.score<25).length;
  $('#suspectFiles').textContent=allResults.filter(r=>r.score>=25&&r.score<60).length;
  $('#dangerFiles').textContent=allResults.filter(r=>r.score>=60).length;
  $('#verifiedCount').textContent=allResults.filter(r=>r.score<25).length;
  $('#detectedCount').textContent=detected.length;
  icons();
}
async function refresh(){
  try{
    const s=await (await fetch('/api/state')).json();allResults=s.results||[];
    const pct=s.total?Math.round(s.progress/s.total*100):0;
    $('#progressBar').style.width=pct+'%';$('#progressPct').textContent=pct+'%';
    $('#progressText').textContent=s.running?`${s.progress} de ${s.total||'…'} arquivos processados`:(s.finished?'Varredura finalizada':'Nenhuma análise em andamento');
    $('#scanStatus').textContent=s.running?'Em andamento':s.finished?'Concluído':'Aguardando';
    $('#lastScan').textContent=s.started?'Iniciada em '+new Date(s.started).toLocaleString('pt-BR'):'Nenhuma verificação nesta sessão';
    $('#logs').innerHTML=(s.logs||[]).slice(-12).reverse().map(x=>`<div class="log-line">${esc(x)}</div>`).join('')||'<div class="empty">Os eventos aparecerão aqui.</div>';
    if(s.folder)$('#defenderState').textContent='Verificação da pasta executada';
    renderTables();
    if(!s.running&&s.finished)$('#startScan').disabled=false;
  }catch(e){}
}
$('#startScan').addEventListener('click',async()=>{
  const folder=$('#folder').value.trim();if(!folder){alert('Informe o caminho da pasta.');return}
  $('#startScan').disabled=true;$('#startScan').innerHTML='<i data-lucide="loader-circle"></i> Iniciando';icons();
  try{const r=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folder,cloud:$('#cloud').checked})});const d=await r.json();if(!r.ok)throw Error(d.error||'Não foi possível iniciar');}
  catch(e){alert(e.message);$('#startScan').disabled=false;}
  finally{$('#startScan').innerHTML='<i data-lucide="play"></i> Iniciar scan';icons();}
});
$('#newScan').addEventListener('click',()=>{showView('dashboard');$('#folder').focus()});
async function loadConfig(){try{const c=await(await fetch('/api/config')).json();$('#cfgDefender').textContent=c.defender_supported?'Disponível no Windows':'Não disponível neste sistema';$('#cfgVT').textContent=c.virus_total?'Chave configurada':'Chave ausente';$('#cfgKas').textContent=c.kaspersky?'Chave configurada':'Chave ausente';$('#limits').textContent=`Até ${c.max_files} arquivos por sessão; máximo de ${c.max_file_mb} MB por arquivo.`;$('#vtState').textContent=c.virus_total?'Configurado':'Sem chave';$('#kasState').textContent=c.kaspersky?'Configurado':'Sem chave';$('#defenderState').textContent=c.defender_supported?'Aguardando':'Windows necessário';}catch(e){}}
icons();loadConfig();refresh();setInterval(refresh,1500);

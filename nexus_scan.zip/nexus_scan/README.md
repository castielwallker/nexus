# NEXUS SCAN — Localhost

Dashboard web local para análise defensiva de arquivos. Interface em português, tema claro/escuro e resultados por risco.

## Requisitos
- Python 3.10+
- Windows 10/11 para usar o Microsoft Defender via `MpCmdRun.exe`
- Chaves próprias para VirusTotal e Kaspersky OpenTIP (opcionais)

## Instalação (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:VT_API_KEY="SUA_CHAVE_VIRUSTOTAL_NOVA"
$env:OPENTIP_API_KEY="SUA_CHAVE_KASPERSKY"
python app.py
```
Abra `http://127.0.0.1:5050`.

No Linux/macOS, execute `python app.py`; o módulo Defender será indicado como indisponível.

## Uso
1. Informe o caminho completo de uma pasta no campo do dashboard.
2. Marque ou desmarque "Consultar APIs".
3. Clique em "Iniciar scan".
4. Veja os arquivos nas abas Verificados, Resultado e Detectados.

## Segurança e limitações
- O servidor escuta somente em `127.0.0.1`; não exponha a porta na rede.
- As APIs recebem somente o SHA-256, não o conteúdo do arquivo.
- A consulta por hash pode revelar à operadora da API que você está investigando aquele hash. Arquivos privados/desconhecidos podem não ter reputação pública.
- Chaves são lidas de variáveis de ambiente, nunca armazenadas no código ou enviadas ao navegador.
- Não há exclusão, quarentena ou execução de arquivos suspeitos.
- A verificação Defender é iniciada na pasta inteira. O retorno do `MpCmdRun` é mostrado como estado geral; não é atribuído individualmente a cada arquivo.
- O MRT não oferece uma interface de linha de comando suportada para varredura arbitrária de pasta; por isso não é iniciado automaticamente.
- "Falso Positivo" é uma categoria manual planejada; esta versão não marca falsos positivos automaticamente.
- Os resultados de reputação são indicativos e não substituem análise forense/antivírus. O score é uma heurística de triagem, não uma probabilidade.
- Por segurança, arquivos acima do limite configurado ou além do limite de quantidade são ignorados.
- O uso do VirusTotal/Kaspersky está sujeito às respectivas políticas, quotas e termos.

## APIs
- VirusTotal API v3: `GET https://www.virustotal.com/api/v3/files/{sha256}`
- Kaspersky OpenTIP: `GET https://opentip.kaspersky.com/api/v1/search/hash?request={sha256}` com header `x-api-key`.

## Observação sobre Defender
O comando de varredura personalizada usa `MpCmdRun.exe -Scan -ScanType 3 -File <pasta>`. A Microsoft documenta `-ScanType 3` como scan personalizado e `-File` como caminho de arquivo/pasta. Em alguns sistemas, execute o terminal como Administrador para garantir as permissões necessárias.
